export class bookInfo{
    book_name:string;
    author_name:string;
    genre:string;
    year_publish:number;
    imgsrc:string;
}