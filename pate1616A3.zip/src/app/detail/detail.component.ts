import { Component, OnInit } from '@angular/core';
import {MYBOOKS} from '../../assets/data/myBooks';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  mybooks = MYBOOKS;  
  book: boolean[] = [];
  constructor() { }

  ngOnInit(): void {
  }

  onClick(i): void{
    this.book[i] = !this.book[i];
  }
 
}
