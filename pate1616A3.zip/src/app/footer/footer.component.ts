import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
    stud_no= 991543965;
    stud_name='Ark';
    login_name='pate1616';
    campus='Davis';
    
  constructor() { }

  ngOnInit(): void {
  }

}
