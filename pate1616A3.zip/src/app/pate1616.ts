export class pate1616  {
    stud_no: number;
    stud_name:string;
    login_name:string;
    campus:string;
    assign_name:string;
   
}