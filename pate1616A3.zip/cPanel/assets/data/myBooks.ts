import {bookInfo} from '../../app/bookInfo';

export const MYBOOKS: bookInfo[]=[
    {book_name:'RobinHood',author_name:'Howard Pyle',genre:'Adventure',year_publish:1883,imgsrc:'assets/images/a.jpg'},
    {book_name:'The story of science',author_name:'Joy Hakim',genre:'Science Fiction',year_publish:1914,imgsrc:'assets/images/b.jpg'},
    {book_name:'Story Thieves',author_name:'James Riley',genre:'Fantasy Fiction',year_publish:2015,imgsrc:'assets/images/c.jpg'},
    {book_name:'The wolf and seven little kids',author_name:'Jacob Grimm',genre:'Fairy Tale',year_publish:1812,imgsrc:'assets/images/d.jpg'}
];