$(document).ready(function () {

        $("#catData").click(function () {

            let cat_sound = $("input[name=cat_sound]:checked").val();

            let cat_message = $("input[name=cat_message]").prop("checked");

            let catData={cat_sound,cat_message};

            console.log(catData);

            localStorage["catData"] = JSON.stringify(catData);


        })

});
