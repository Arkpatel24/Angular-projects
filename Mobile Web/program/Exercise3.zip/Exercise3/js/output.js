$(document).ready(function () {
    let catData = JSON.parse(localStorage["catData"]);
    $("#cat_sound").text(catData.cat_sound);
    $("#cat_message").text(catData.cat_message?"yes":"no");
});