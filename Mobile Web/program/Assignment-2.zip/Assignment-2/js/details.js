$(function() {

    let breed = JSON.parse(localStorage["breed"]);
    $("span.cat_name").text(breed.name);
    $("img.breed_image")
        .attr("src",`images/cats/${breed.pictures.large}`)
        .attr("alt",breed.name);
    $("span.cat_text").text(breed.text);
    $("span.cat_link").html(breed.link);
});