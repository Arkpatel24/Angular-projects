$(document).ready(function () {
    let dog= JSON.parse(localStorage["dog"]);
    $("#name").text(dog.name);
    $("#owner").text(dog.owner);
    $("#vaccine").text(dog.vaccine?"Given Vaccine":"Not given Vaccine");
})