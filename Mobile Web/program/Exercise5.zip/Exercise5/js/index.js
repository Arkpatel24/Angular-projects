$(document).ready(function () {
    $("#form").submit(Data);
})

function Data(form){
    let name= $(`input[name=name]`).val();
    let owner= $(`input[name=owner]`).val();

    let vaccine= $(`input[name=vaccine]`).prop("checked");

    let dog={name, owner, vaccine};

    localStorage["dog"]=JSON.stringify(dog);
}