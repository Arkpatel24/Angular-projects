function Cat(catName,catAge) {
    this.catName=catName;
    this.catAge=catAge;
}

let Cats = [new Cat("Oscar",4),new Cat("Missy",2),new Cat("Cleo",6)]

function displayCat() {

    let table = document.getElementById("cat_table");
    for (let i=0; i<Cats.length ;i++)
         {
            let cat= Cats[i];
             let row = ` <tr>
                <td>${i+1}</td>
                <td>${cat.catName}</td>
                <td>${cat.catAge}</td>
                </tr>`;

             table.innerHTML += row;
        }
}