function get_Red() {
    return `images/traffic_light/red_light.jpg`;
}

function get_Yellow() {
    return `images/traffic_light/yellow_light.jpg`;
}

function get_Green() {
    return `images/traffic_light/green_light.jpg`;
}

$(document).ready(function () {
    const $image = $("#light_image");

    $("#red_btn").click(function () {
        let red = get_Red();
        $image.attr("src",red);
    });

    $("#yellow_btn").click(function () {
        let yellow = get_Yellow();
        $image.attr("src",yellow);
    });

    $("#green_btn").click(function () {
        let green = get_Green();
        $image.attr("src",green);
    });
});

