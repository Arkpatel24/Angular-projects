$(document).ready(function () {
    $("#form").submit(CustomerData);
});

function CustomerData(form)
{
    let name=$("input[name=name]").val();
    let width=$("input[name=width]").val();
    let length=$("input[name=length]").val();
    let color=$("input[name=color]").val();
    let paint=$("select[name=paint]").val();

    let data= {name, width, length, color, paint};

    localStorage["data"]= JSON.stringify(data);

    form.submit();

}