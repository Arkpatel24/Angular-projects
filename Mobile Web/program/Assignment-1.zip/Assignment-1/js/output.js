$(document).ready(function ()
{
    let data= JSON.parse(localStorage["data"]);

    $("#name").text(data.name);
    $("#width").text(data.width);
    $("#length").text(data.length);
   // $("#color").text(data.color);
    $("#color").css('background-color',data.color);
    let width=data.width;
    let length=data.length;
    let paint=data.paint;

    let area=width*length;
    let price= ((area/400)*paint)*0.13;

    $("#paint").text(price.toFixed(2));
});