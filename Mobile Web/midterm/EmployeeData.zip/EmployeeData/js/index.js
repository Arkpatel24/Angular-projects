$(function()
    {
        $.getJSON("data/empdata/empdata.json",Data);

    }
)

function Data(data)
{
    let $table=$("<table></table>");
    $table.appendTo("main");
    let employee = data.employee;


    employee.forEach(function(employee, index){

        $table.append(
            `
            <tr>
                <td>
                  <span class="name">${employee.name}</span>
                </td>
                
                 <td>
                   <span class="salary">${employee.salary}</span> 
                </td>
                
                <td>
                 <span class="status">${employee.FullTimeStatus}</span> 
                </td>
            
            </tr>
              `

        )

    } );



}