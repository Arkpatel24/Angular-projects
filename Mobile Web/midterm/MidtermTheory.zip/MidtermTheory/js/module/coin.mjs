class Coin {
    #valueOfCoin
    constructor(valueCoin=25) {
        this.#valueOfCoin=this.#valueOfCoin
    }
    get valueOfCoin(){
        return this.#valueOfCoin;
    }
    set valueOfCoin(coinvalue){
        if(coinvalue==5){
            this.#valueOfCoin=coinvalue;
        }
        else if(coinvalue==10){
            this.#valueOfCoin=coinvalue;
        }
        else if( coinvalue==25) {
            this.#valueOfCoin=coinvalue;
        }
        else{
            throw new Error("Illegal Coin Value");
        }
    }
    get name(){
        if(this.#valueOfCoin==5){
            console.log("nickle");
        }
        else if(this.#valueOfCoin==10){
            console.log("dime");
        }
        else if(this.#valueOfCoin==25){
            console.log("quater");
        }
    }
}

export {Coin}