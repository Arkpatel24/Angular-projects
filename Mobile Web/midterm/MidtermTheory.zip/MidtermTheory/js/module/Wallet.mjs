import {Coin} from "./coin.mjs";
class Wallet {
    #coins;

    constructor() {
        this.#coins=[];
    }

    get coinCount(){
        return this.#coins.length;
    }

    get coins(){
        return this.#coins;
    }
    get total() {
        let t=0;
        for(let i=0;i<this.#coins.length;i++)
        {
            t += this.#coins[i].valueOfCoin;
        }
        return t;
    }
    addCoin(coin){
        this.#coins.push(coin);
    }
    get removeCoin(){
        if(this.#coins.length!=0){
            return this.#coins.pop();
        }
        else {
            throw new Error("Cannot remove a coin, the wallet is empty");
        }
    }
}
export {Wallet}