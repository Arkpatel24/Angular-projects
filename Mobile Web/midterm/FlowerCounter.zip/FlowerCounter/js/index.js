$(document).ready(function () {

    $("#btn").click(function () {
        let rose=0;
        let daisy=0;


        if($(`input[name=flow]:checked`,`#form`).val()=="rose")
        {
            rose++;
            $("#rose").html(rose);
        }
        else if($(`input[name=flow]:checked`,`#form`).val()=="daisy")
        {
            daisy++;
            $("#dais").text(daisy);
        }


    });
    $('#r').click(function () {
        rose=0;
        daisy=0;

        $("#rose").html(rose);
        $("#dais").html(daisy);

    })

});
